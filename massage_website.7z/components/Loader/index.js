const Loader = () => {
	return <div className='preloader' />;
};

export default Loader;
