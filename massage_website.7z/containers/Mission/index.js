const Mission = () => {
	return (
		<section className='vission-misson-section bg-four mb-150 rmb-100'>
			<div className='container'>
				<div className='row'>
					<div className='col-lg-6'>
						<div className='mission vission-mission'>
							<h3>Our Mission.</h3>
							<h6>
								Saunas are used all over the world to improve health enjoy
								relax. During the clients stay in sauna, body is sweating and
								from harmful substances and toxins.
							</h6>
							<p>
								It has different attractions – tropical rain, fog, dew, wall
								jets and it is combined with sound, caribbian storm, aroma and
								various lighting effects, what makes you have an unforgettable
								filling.
							</p>
							<a href='services.html' className='theme-btn style-two mt-15'>
								Our Services
							</a>
						</div>
					</div>
					<div className='col-lg-6'>
						<div className='vission vission-mission bg-three text-white'>
							<h3>Our Vission.</h3>
							<p>
								It has different attractions – tropical rain, fog, dew, wall
								jets and it is combined with sound, caribbian storm, aroma and
								various lighting effects, what makes you have an unforgettable
								filling.
							</p>
							<p>
								It has different attractions – tropical rain, fog, dew, wall
								jets and it is combined with sound, caribbian storm, aroma and
								various lighting effects, what makes you have an unforgettable
								filling.
							</p>
							<a href='team.html' className='theme-btn style-four mt-15'>
								Our Experts
							</a>
						</div>
					</div>
				</div>
			</div>
		</section>
	);
};

export default Mission;
