const Services = () => {
	return <div>Enter</div>;
};

export default Services;
